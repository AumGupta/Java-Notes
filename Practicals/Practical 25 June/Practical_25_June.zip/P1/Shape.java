package P1;

public abstract class Shape {
    protected abstract double area();
}
